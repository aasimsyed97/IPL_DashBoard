package com.IPL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
